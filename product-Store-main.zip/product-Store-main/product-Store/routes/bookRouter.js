import express from 'express';
import {
    getAllBooksController,
    getBookByIdController,
    createBookController,
    updateBookController,
    deleteBookController,
    getBooksByCategoryController,
    getBooksByAuthorController
} from '../controllers/bookController.js';
import { admin, authenticated } from '../utils/middleware/index.js';

const bookRouter = express.Router();

// 📚 عرض كل الكتب - متاح للجميع بدون تسجيل دخول
bookRouter.get('/', getAllBooksController);

// 🆕 إضافة كتاب جديد - يتطلب تسجيل دخول وصلاحية admin
bookRouter.post('/', authenticated, admin, createBookController);

// 📖 عرض كتاب محدد - يتطلب تسجيل دخول
bookRouter.get('/:id', authenticated, getBookByIdController);

// ✏️ تحديث كتاب - يتطلب تسجيل دخول وصلاحية admin
bookRouter.put('/:id', authenticated, admin, updateBookController);

// 🗑️ حذف كتاب - يتطلب تسجيل دخول وصلاحية admin
bookRouter.delete('/:id', authenticated, admin, deleteBookController);

// 🗂️ عرض الكتب حسب التصنيف - يتطلب تسجيل دخول
bookRouter.get('/category/:categoryId', authenticated, getBooksByCategoryController);

// ✍️ عرض الكتب حسب المؤلف - يتطلب تسجيل دخول
bookRouter.get('/author/:authorId', authenticated, getBooksByAuthorController);

export default bookRouter;
