import express from 'express';
import {
    getUsers,
    registerUser,
    signInUser,
    getUserByIdController,
    updateUserController,
    deleteUserController,
    getCart,
    clearCartController,
    putCartController
} from '../controllers/userController.js';

import { admin, authenticated, hasAccess } from '../utils/middleware/index.js';

const userRouter = express.Router();

// 🆕 تسجيل مستخدم جديد
userRouter.post('/signup', registerUser);

// 🔐 تسجيل الدخول
userRouter.post('/signin', signInUser);

// 👥 عرض كل المستخدمين (admin فقط)
userRouter.get('/', authenticated, admin, getUsers);

// 📄 عرض مستخدم واحد بصلاحياته
userRouter.get('/:id', authenticated, hasAccess, getUserByIdController);

// ✏️ تعديل مستخدم
userRouter.put('/:id', authenticated, hasAccess, updateUserController);

// 🗑️ حذف مستخدم
userRouter.delete('/:id', authenticated, hasAccess, deleteUserController);

// 🛒 كارت المستخدم
userRouter.get('/cart', authenticated, getCart);
userRouter.put('/cart', authenticated, putCartController);
userRouter.delete('/cart', authenticated, clearCartController);

export default userRouter;
        